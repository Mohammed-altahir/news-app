import 'package:firebase_setup_android/news.dart';

import 'dart:convert';
import 'package:http/http.dart' as http;

class CryptoAPI {
  static Future<List<Crypto>> getCrypto() async {
    var uri = Uri.https('newsapi.org', '/v2/everything',
        {"q": "Apple", "from": "2022-03-14", "sortBy": "popularity"});
    final response = await http.get(uri, headers: {
      "x-api-Key": "YOUR API KEY FROM newsapi.org",
      "useQueryString": "true"
    });
    Map data = jsonDecode(response.body);

    List _temp = [];

    for (var item in data['articles']) {
      if (item['author'] == null) {
        item['author'] = 'Anonymous';
      }
      _temp.add({
        'title': item['title'],
        'urlToImage': item['urlToImage'],
        'author': item['author'],
        'publishedAt':item['publishedAt'],
        'content':item['content']
      });
      print(_temp);
    }

    return Crypto.cryptoFromSnapshot(_temp);
  }
}

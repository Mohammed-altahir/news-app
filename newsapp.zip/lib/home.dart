import 'package:flutter/material.dart';

import 'news.dart';
import 'news_api.dart';
import 'news_card.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late List<Crypto> _crypto;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    getcrypto();
  }

  Future<void> getcrypto() async {
    _crypto = await CryptoAPI.getCrypto();
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(Icons.local_fire_department_rounded),
              SizedBox(width: 10),
              Text('Top News')
            ],
          ),
        ),
        
        body: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                itemCount: _crypto.length,
                itemBuilder: (context, index) {
                  
                  return CryptoCard(
                      publishedAt:_crypto[index].publishedAt,
                      title: _crypto[index].title,
                      author: _crypto[index].author,
                      thumbnailUrl: _crypto[index].images,
                      content: _crypto[index].content
                      );
                },
              ));
  }
}
class Crypto {
  final String title, images, author,publishedAt,content;

  Crypto({required this.title, required this.images, required this.author,required this.publishedAt,required this.content});

  factory Crypto.fromJson(dynamic json) {
    return Crypto(
        title: json['title'] ,
        images: json['urlToImage'],
        author: json['author'],
        publishedAt: json['publishedAt'],
        content: json['content']);
        
  }

  static List<Crypto> cryptoFromSnapshot(List snapshot) {
    return snapshot.map((data) {
      return Crypto.fromJson(data);
    }).toList();
  }

  @override
  String toString() {
    return "Crypto {title:$title,images:$images,author:$author}";
  }
}

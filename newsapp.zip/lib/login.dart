import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_setup_android/home.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'google_auth.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        title: const Text('Login'),
      ),
      body: const Body(),
      
    );
  }
}

class Body extends StatefulWidget {
  const Body({Key? key}) : super(key: key);

  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  late User user;
  @override
  void initState() {
    super.initState();
    signOutGoogle();
  }

  void click() {
    signInWithGoogle().then((user) {
      print("success");
      this.user = user;
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => HomePage(/*user*/)));
    });
  }

  Widget googleLoginButton() {
    return Column(
      
      children: <Widget>[
        const SizedBox(
          height: 20,
        ),
        const Text("Wellcome to worldwide top news",style: TextStyle(fontSize: 20),),
        const SizedBox(height: 20,),
        OutlineButton(
          onPressed: this.click,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(45)),
          splashColor: Colors.white,
          borderSide: const BorderSide(color: Colors.white),
          child: Padding(
            padding:const EdgeInsets.fromLTRB(0, 10, 0, 10),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: const <Widget>[
                Image(image: AssetImage('assets/NoPath.png')),

                Padding(
                  padding: EdgeInsets.only(left: 10),
                  child: Text(
                    "Sign in with google",
                    style: TextStyle(color: Colors.white, fontSize: 25),
                  ),
                ),
                
              ],
            ),
          ),
        ),
        SizedBox(height: 420),
        Text("POWERED BY newsapi.org",style: const TextStyle(fontFamily: "Arial",fontSize: 18),)
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Align(alignment: Alignment.topCenter, child: googleLoginButton());
  }
}
